.. _askbot.middleware:

:mod:`askbot.middleware`
=================

.. automodule:: askbot.middleware
    :members:
    :undoc-members:
    :show-inheritance:

.. _modules::

:mod:`Modules`
-------


* :ref:`askbot.middleware.anon_user`
* :ref:`askbot.middleware.cancel`
* :ref:`askbot.middleware.pagesize`
* :ref:`askbot.middleware.spaceless`
* :ref:`askbot.middleware.view_log`

