.. _askbot.migrations.0014_rename_schema_from_forum_to_askbot:

:mod:`askbot.migrations.0014_rename_schema_from_forum_to_askbot`
=========================================================

.. automodule:: askbot.migrations.0014_rename_schema_from_forum_to_askbot
    :members:
    :undoc-members:
    :show-inheritance:

