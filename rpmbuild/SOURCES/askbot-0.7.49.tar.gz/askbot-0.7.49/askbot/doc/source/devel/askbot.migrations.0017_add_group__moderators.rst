.. _askbot.migrations.0017_add_group__moderators:

:mod:`askbot.migrations.0017_add_group__moderators`
============================================

.. automodule:: askbot.migrations.0017_add_group__moderators
    :members:
    :undoc-members:
    :show-inheritance:

