.. _askbot.conf.skin_counter_settings:

:mod:`askbot.conf.skin_counter_settings`
=================================

.. automodule:: askbot.conf.skin_counter_settings
    :members:
    :undoc-members:
    :show-inheritance:

