.. _askbot.middleware.cancel:

:mod:`askbot.middleware.cancel`
========================

.. automodule:: askbot.middleware.cancel
    :members:
    :undoc-members:
    :show-inheritance:

