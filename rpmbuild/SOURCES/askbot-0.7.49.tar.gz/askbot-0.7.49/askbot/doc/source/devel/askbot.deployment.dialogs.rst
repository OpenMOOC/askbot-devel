.. _askbot.deployment.dialogs:

:mod:`askbot.deployment.dialogs`
=========================

.. automodule:: askbot.deployment.dialogs
    :members:
    :undoc-members:
    :show-inheritance:

