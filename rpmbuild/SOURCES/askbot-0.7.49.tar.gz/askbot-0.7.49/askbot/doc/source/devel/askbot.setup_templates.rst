.. _askbot.setup_templates:

:mod:`askbot.setup_templates`
======================

.. automodule:: askbot.setup_templates
    :members:
    :undoc-members:
    :show-inheritance:

.. _modules::

:mod:`Modules`
-------


* :ref:`askbot.setup_templates.manage`
* :ref:`askbot.setup_templates.settings`
* :ref:`askbot.setup_templates.urls`

