.. _askbot.const:

:mod:`askbot.const`
============

.. automodule:: askbot.const
    :members:
    :undoc-members:
    :show-inheritance:

.. _modules::

:mod:`Modules`
-------


* :ref:`askbot.const.message_keys`

