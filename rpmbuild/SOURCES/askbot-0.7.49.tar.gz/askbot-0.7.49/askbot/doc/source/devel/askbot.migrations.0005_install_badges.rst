.. _askbot.migrations.0005_install_badges:

:mod:`askbot.migrations.0005_install_badges`
=====================================

.. automodule:: askbot.migrations.0005_install_badges
    :members:
    :undoc-members:
    :show-inheritance:

