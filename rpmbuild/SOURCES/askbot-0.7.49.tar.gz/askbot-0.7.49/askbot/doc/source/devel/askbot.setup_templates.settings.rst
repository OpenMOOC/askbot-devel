.. _askbot.setup_templates.settings:

:mod:`askbot.setup_templates.settings`
===============================

.. automodule:: askbot.setup_templates.settings
    :members:
    :undoc-members:
    :show-inheritance:

