.. _askbot.conf.site_settings:

:mod:`askbot.conf.site_settings`
=========================

.. automodule:: askbot.conf.site_settings
    :members:
    :undoc-members:
    :show-inheritance:

