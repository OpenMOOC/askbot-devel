.. _askbot.setup_templates.manage:

:mod:`askbot.setup_templates.manage`
=============================

.. automodule:: askbot.setup_templates.manage
    :members:
    :undoc-members:
    :show-inheritance:

