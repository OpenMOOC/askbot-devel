.. _askbot.templatetags.smart_if:

:mod:`askbot.templatetags.smart_if`
============================

.. automodule:: askbot.templatetags.smart_if
    :members:
    :undoc-members:
    :show-inheritance:

