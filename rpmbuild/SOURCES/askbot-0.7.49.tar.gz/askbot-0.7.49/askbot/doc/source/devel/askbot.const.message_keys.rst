.. _askbot.const.message_keys:

:mod:`askbot.const.message_keys`
=========================

.. automodule:: askbot.const.message_keys
    :members:
    :undoc-members:
    :show-inheritance:

