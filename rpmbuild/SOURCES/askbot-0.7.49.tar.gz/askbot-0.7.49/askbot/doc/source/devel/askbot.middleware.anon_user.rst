.. _askbot.middleware.anon_user:

:mod:`askbot.middleware.anon_user`
===========================

.. automodule:: askbot.middleware.anon_user
    :members:
    :undoc-members:
    :show-inheritance:

