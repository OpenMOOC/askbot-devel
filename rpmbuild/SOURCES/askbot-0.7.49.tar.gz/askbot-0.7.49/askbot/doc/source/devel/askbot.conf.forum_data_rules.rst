.. _askbot.conf.forum_data_rules:

:mod:`askbot.conf.forum_data_rules`
============================

.. automodule:: askbot.conf.forum_data_rules
    :members:
    :undoc-members:
    :show-inheritance:

