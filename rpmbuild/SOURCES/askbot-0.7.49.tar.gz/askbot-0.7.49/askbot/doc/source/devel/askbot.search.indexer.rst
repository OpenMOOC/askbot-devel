.. _askbot.search.indexer:

:mod:`askbot.search.indexer`
=====================

.. automodule:: askbot.search.indexer
    :members:
    :undoc-members:
    :show-inheritance:

