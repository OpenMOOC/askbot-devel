.. _askbot.middleware.spaceless:

:mod:`askbot.middleware.spaceless`
===========================

.. automodule:: askbot.middleware.spaceless
    :members:
    :undoc-members:
    :show-inheritance:

