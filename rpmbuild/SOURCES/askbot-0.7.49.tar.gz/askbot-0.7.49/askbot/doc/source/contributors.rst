==============================
Contributors to Askbot Project
==============================

This is the list of contributors to the code of Askbot project.
The list is probably incomplete, apologies for any omissions.
Thanks for all your help

Programming, bug fixes and documentation
----------------------------------------
* Mike Chen & Sailing Cai - original authors of CNPROG forum
* Evgeny Fadeev - founder of askbot
* `Adolfo Fitoria <http://fitoria.net>`_
* `Tomasz Zielinski <http://pyconsultant.eu/>`_
* `Sayan Chowdhury <http://fosswithme.wordpress.com>`_
* Andy Knotts
* Benoit Lavine (with Windriver Software, Inc.)
* Jeff Madynski
* `Jishnu <http://thecodecracker.com/>`_
* `Hrishi <https://github.com/stultus>`_
* Andrei Mamoutkine
* `Daniel Mican <http://www.crunchbase.com/person/daniel-mican>`_
* `Dejan Noveski <http://www.atomidata.com/>`_
* `Vasil Vangelovski <http://www.atomidata.com/>`_
* `Ramiro Morales <http://rmorales.com.ar/>`_ (with Machinalis)
* Vladimir Bokov
* `NoahY <https://github.com/NoahY>`_
* `Gael Pasgrimaud <http://www.gawel.org/>`_ (bearstech)
* `Arun SAG  <http://zer0c00l.in/>`_
* `Rag Sagar <https://github.com/ragsagar>`_
* `Alex Robbins <https://github.com/alexrobbins>`_
* `Tomasz Szynalski <http://antimoon.com>`_
* `Raghu Udiyar <http://raags.tumblr.com/>`_
* `Alexander Werner <https://twitter.com/#!/bundeswerner>`_
* Rosandra Cuello Suñol 
* `hjwp <https://github.com/hjwp>`_
* `Jacob Oscarson <http://www.aspektratio.net>`_
* `Radim Řehůřek <https://github.com/piskvorky>`_
* `monkut <https://github.com/monkut>`_
* `Jim Tittsler <http://wikieducator.org/User:JimTittsler>`_
* Silvio Heuberger
* `Alexandros <https://github.com/alexandros-z>`_
* `Paul Backhouse <https://github.com/powlo>`_
* `jtrain <https://github.com/jtrain>`_
* Niki Rocco
* `Tyler Mandry <https://github.com/tmandry>`_
* `Jorge López Pérez <https://github.com/adobo>`_
* `Zafer Cakmak <https://github.com/xaph>`_
* `Kevin Porterfield <http://www.shotgunsoftware.com>_`
* `Robert Martin <https://github.com/bobbydavid>_`
* `Director <http://codeflow.co.kr>`_

Translations
------------
Thanks for the help to all translators.
If you believe you were incorrectly missed out of this list,
please let us know at support@askbot.com.

* Mike Chen, Sailing Cai, suyu8776 - Chinese
* Bruno Sarlo, Adolfo Fitoria, Francisco Espinoza - Spanish
* Evgeny Kalinin, Andrey Komrachkov - Russian
* Evgeny Fadeev - English
* Oktay Yildiz, Onur Mat, Cemre - Turkish
* Jérôme Blondon (bearstech) - French
* Pekka Gaiser, Edur - German
* Pekka Järvinen - Finnish
* Adi Robian - Romanian
* `Stefano Mancini <https://github.com/xponrails>`_, Dario Ghilardi, Federico Poloni, `Luca Ferroni <http://www.linkedin.com/in/lucaferroni>`_ - Italian
* Cong It, Nguyen Long, ppranhh - Vietnamese
* `Jordi Bofill <https://github.gom/jbofill>`_ - Catalan
* Vašek Chalupníček - Chech
* Dario Kolak - Croatian
.
